## GvMeABreak
<p>presents.</p>

<h2 align="center">“7th Layer”</h2>
<h2 align="center">Simple Websocket Server</h2>

#### Executing the Project
1. get the copy of server.py file.
2. open the terminal and execute the following command.
    ```
    python server.py
    ```

#### Working Percentage
| NIM       | Nama                  | what has been done?                                   | percentage  |
| :---      | :---:                 | :---:                                                 | ---:        |
| 13517053  | Jesslyn Nathania      | handshake, framing, control frame, command-handler    | 33.3        |
| 13517068  | Abel Stanley          | handshake, framing, control frame, command-handler    | 33.3        |
| 13517119  | Stefanus Ardi Mulia   | handshake, framing, control frame, command-handler    | 33.3        |


